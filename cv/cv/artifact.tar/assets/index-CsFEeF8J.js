import{j as e}from"./index-oT0UlOWa.js";function t(){return e.jsx(e.Fragment,{children:"Home"})}export{t as default};
