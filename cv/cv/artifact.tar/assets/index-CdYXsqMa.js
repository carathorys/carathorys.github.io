import{j as t}from"./index-oT0UlOWa.js";function r(){return t.jsx(t.Fragment,{children:"Skills"})}export{r as default};
